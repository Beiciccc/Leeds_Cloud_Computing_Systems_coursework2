# Performance Evaluation of Kubernetes for Cloud and Edge Network Functions

## Abstract

This coursework evaluates Kubernetes support for a lightweight telecom-relevant virtual network function in two lab-scale environments: a cloud-like deployment using kind and an edge-like deployment using K3s. The selected VNF is a dedicated CoreDNS instance serving a custom `telecom.local` zone. The same manifests, DNS records, validation steps, and benchmark scenarios were used in both environments to preserve fairness. Functional validation was performed using `nslookup`, while performance was measured using a custom Python DNS benchmark client together with Kubernetes resource snapshots.

The experiments were executed successfully in both environments. Hello-world validation succeeded in both the kind-based cloud-like cluster and the K3s-based edge-like cluster. Across all completed benchmark scenarios, both environments achieved 100% successful DNS queries. However, the two platforms differed substantially in latency behaviour. The cloud-like kind environment showed average latency of 4.50 ms in the baseline scenario and around 3.10-4.07 ms under sustained load, but this increased to 17.90 ms under burst load, with severe tail-latency spikes. By contrast, the edge-like K3s environment achieved much lower latency throughout, including about 1.03 ms at baseline and about 0.53 ms under burst load. Resource measurements were also captured successfully in both environments and showed that the CoreDNS pod remained lightweight in each case. These results suggest that, for this lightweight DNS VNF and this lab configuration, the edge-like K3s environment delivered lower and more stable latency than the cloud-like kind environment, while both retained full functional correctness and 100% success rates.

## 1. Motivation and Problem Framing

Kubernetes is increasingly used to orchestrate network functions that were historically deployed as tightly managed appliances or VM-centric services [1]. In telecom systems this shift matters because control functions, edge-local services, and service-discovery components must now be deployed under heterogeneous operating conditions ranging from central cloud infrastructure to resource-constrained edge nodes. The coursework therefore asks not only whether a network function can run in Kubernetes, but whether equivalent deployments behave differently when the Kubernetes distribution itself changes. Existing performance studies also show that Kubernetes and container networking overheads can vary meaningfully with the platform and deployment context, which supports the need for an explicit cloud-versus-edge comparison rather than assuming identical behaviour everywhere [7]-[9].

This project studies that question using a deliberately lightweight DNS VNF rather than a heavyweight 5G core. The decision is methodological rather than evasive. A small VNF is easier to isolate, cheaper to repeat, and less likely to exceed the assignment limits on CPU and memory. It also reduces the risk that the comparison becomes dominated by unrelated subsystems such as databases, service meshes, or multi-function control-plane dependencies. This narrower design also aligns better with the lab-scale character of the environment described in practical Kubernetes and edge-performance work [7], [9].

## 2. Selected VNF and Justification

The selected VNF is CoreDNS configured as an experimental DNS service, separate from the cluster-default DNS. This is an appropriate telecom-oriented choice for three reasons. First, DNS and service discovery are operationally important in distributed systems that include central and edge sites. Second, CoreDNS is container-native and straightforward to deploy via Kubernetes manifests [4]. Third, the workload is sufficiently lightweight to support repeated measurements on single-node lab clusters.

The VNF serves a custom `telecom.local` zone with four records that represent plausible telecom-style endpoints: `ue1.telecom.local`, `upf.telecom.local`, `amf.telecom.local`, and `edge-cache.telecom.local`. These names provide a stable and realistic test set without requiring a full 5G control plane. The service uses the CoreDNS `hosts` plugin to provide deterministic local responses [5], and it keeps the same image, configuration, and resource limits in both environments so that the comparison focuses on the orchestration stack rather than on application drift. The deployment stays within a conservative lab-scale resource envelope: the manifest requests 25 millicores and 32 MiB, and caps the pod at 200 millicores and 128 MiB, which is appropriate for matched single-node cloud-like and edge-like VMs.

## 3. Cloud-Like and Edge-Like Environments

The cloud-like environment uses kind, which provides a full Kubernetes control plane running inside Docker-backed nodes [2]. The edge-like environment uses K3s, a lightweight Kubernetes distribution explicitly designed to reduce operational overhead [3]. Both environments were run on two cloned Ubuntu 22.04.5 LTS ARM64 virtual machines with identical allocations: 2 vCPU, 4 GB RAM, and a 20 GB virtual disk, with Ubuntu exposing about 3.8 GiB of usable memory and about 19 GiB in the root filesystem. This kept the host-side comparison controlled while the VNF manifests, benchmark client, scenario durations, and repeat count remained the same unless a platform-specific difference was unavoidable. The kind node itself reports Debian GNU/Linux 13 in `kubectl get nodes -o wide` because kind packages Kubernetes nodes as containers, but the underlying host VM used for the cloud-like environment was still the same Ubuntu 22.04.5 ARM64 base image as the K3s VM.

K3s includes components that would make the comparison less clean if left enabled by default. To reduce unnecessary background activity, the coursework configuration disables Traefik and the bundled service load balancer. For kind, metrics-server is added because `kubectl top` is not available by default [6]. These are reasonable normalisation steps rather than distortions, because they reduce environment-specific noise and keep the measurement path focused on the DNS VNF.

## 4. VNF Deployment and Hello-World Validation

The deployment logic is identical in both environments. A namespace named `telecom-dns` is created, followed by a ConfigMap holding the CoreDNS `Corefile` and `telecom.hosts` file. A single-replica `Deployment` runs `coredns/coredns:1.11.1` with fixed resource requests and limits. A `ClusterIP` service exposes the VNF on UDP and TCP port 53 inside the cluster. A lightweight BusyBox pod acts as the validation client, while a separate Python runner pod is used for repeatable load generation.

The basic validation path required by the assignment is explicit and reproducible. The script `scripts/test/hello_world.sh` runs `nslookup` from the client pod against the experimental CoreDNS service and verifies that the expected telecom record values are returned. This confirms correct deployment, service reachability, and zone-data loading before performance testing begins, consistent with the way CoreDNS is expected to serve local records through its configured plugins [4], [5].

## 5. Experimental Design and Monitoring

The benchmark design contains three categories. The first is a baseline low-rate scenario to confirm correctness and estimate single-query latency. The second is a sustained-load set with low, medium, and high offered query rates over fixed 60-second windows. The third is a short burst scenario with higher concurrency to observe responsiveness under transient spikes. Each scenario is configured in `scripts/benchmark/experiment_profiles.csv` and is repeated three times by default.

The benchmark client is implemented in `scripts/benchmark/dns_benchmark.py` using only the Python standard library. This keeps the tooling lightweight and avoids reliance on external packages inside the benchmark container. The client sends DNS requests directly to the experimental CoreDNS service, records per-request latency, and reports achieved throughput, success rate, and selected latency percentiles. In parallel, `kubectl top` samples are captured into CSV files to estimate CPU and memory consumption through the Kubernetes resource-metrics path [6]. The aggregation step combines these outputs into processed tables suitable for the report and Gradescope answers.

## 6. Results and Discussion

Hello-world validation succeeded in both environments. In both the cloud-like kind cluster and the edge-like K3s cluster, the experimental CoreDNS VNF successfully served the custom `telecom.local` records and correctly resolved `amf.telecom.local`, `upf.telecom.local`, `ue1.telecom.local`, and `edge-cache.telecom.local`. This confirmed that the same VNF image, manifests, and DNS zone configuration were working correctly in both Kubernetes environments before performance testing began.

### 6.1 Overall functional outcome

Both environments completed the benchmark suite successfully. The processed benchmark results showed a 100% query success rate across all completed scenarios in both environments. This is important because it means that the comparison is not between a working platform and a failing one; instead, both kind and K3s were operationally valid for this DNS VNF under the tested conditions.

### 6.2 Latency comparison

The strongest difference between the two environments was latency. In the cloud-like kind environment, the average DNS latency was 4.50 ms in the baseline scenario, then approximately 4.07 ms, 3.59 ms, and 3.10 ms in the sustained low, medium, and high scenarios respectively. Under burst traffic, however, average latency rose sharply to 17.90 ms.

In the edge-like K3s environment, latency was consistently lower. The average latency was approximately 1.03 ms in the baseline scenario, then 0.85 ms, 0.64 ms, and 0.49 ms under sustained low, medium, and high load respectively. In the burst scenario, average latency remained very low at approximately 0.53 ms.

This means that although both environments handled the DNS workload correctly, the K3s edge-like environment delivered significantly lower average latency than the kind cloud-like environment in every tested scenario. The contrast was especially strong under burst traffic, where the cloud-like environment showed a clear latency penalty while the edge-like environment remained fast.

### 6.3 Throughput and success rate

Throughput results were effectively matched to the benchmark targets in both environments. K3s achieved the intended offered query rates across all scenarios, while kind also remained very close to target and only fell slightly below the nominal 400 qps mark in the burst case, achieving about 398.08 qps on average. Since successful query rates remained at 100% throughout, the main practical difference was not throughput capacity but response-time behaviour. This is an important observation for telecom-style service discovery functions, because these functions often care more about low and predictable latency than about very high bandwidth.

### 6.4 Tail-latency behaviour

The cloud-like kind environment showed a much worse burst profile than the edge-like K3s environment. Although the cloud-side burst tests still achieved 100% success, the average latency rose to around 17.90 ms and the maximum recorded latency reached the multi-second range, indicating severe tail-latency outliers. By contrast, the edge-like K3s burst tests also achieved 100% success but maintained sub-millisecond average latency and much tighter tail behaviour, with maximum latency only in the single-digit millisecond range.

This is one of the most important findings of the coursework. It suggests that the lightweight DNS VNF remained robust in both environments, but the cloud-like kind setup was much more vulnerable to burst-induced latency spikes, whereas the edge-like K3s setup provided a more stable latency profile.

### 6.5 Resource and deployment observations

The practical deployment experience also differed slightly. kind required Docker, an explicitly created cluster, and context-name handling that did not initially match the benchmark script assumptions. K3s, by contrast, was lightweight and fast to install, but needed a kubeconfig permission workaround so that the non-root user could run ordinary `kubectl` commands. In both cases, the VNF could ultimately be deployed with the same manifests, which supports the claim that Kubernetes portability was preserved.

Resource measurements were captured successfully in both environments after re-running the cloud-side tests. The processed results show that the CoreDNS pod remained lightweight throughout. In the baseline scenario, kind averaged about 1.13 millicores and 12.0 MiB, while K3s averaged about 1.35 millicores and 10.58 MiB. Under sustained medium load, the figures were similarly close, with kind at about 10.51 millicores and 14.0 MiB versus K3s at about 10.12 millicores and 14.0 MiB. Under sustained high load, both stayed near 15-16 millicores and around 14-15 MiB. Under burst load, K3s showed higher average CPU usage at about 21.11 millicores than kind at 16.0 millicores, yet still delivered far lower latency. This suggests that the large latency gap cannot be explained simply by the CoreDNS pod consuming dramatically more CPU or memory in kind.

### 6.6 Comparison with expectations and wider interpretation

The results support the hypothesis that a lightweight DNS VNF is feasible in both cloud-like and edge-like Kubernetes environments. However, in this specific lab setup, the edge-like K3s environment clearly performed better in latency terms. This is consistent with the idea that a lighter orchestration stack may introduce less overhead for a small network function, especially in a single-node edge-style deployment. The resource measurements strengthen this interpretation because both environments kept CoreDNS resource consumption modest, yet their latency behaviour still diverged sharply. This reading is also consistent with prior performance work showing that orchestration and networking choices can materially affect latency even when application functionality remains intact [7]-[9].

At the same time, the cloud-like kind environment still demonstrated good operational stability. It successfully deployed the same VNF, completed all benchmark scenarios, and maintained 100% query success. Therefore, the comparison should not be interpreted as “cloud failed and edge succeeded”, but rather as “both worked, while edge delivered lower and more stable latency for this particular workload”.

### 6.7 Limitations of the results

These results should be interpreted within the limits of the coursework design. The experiments were conducted on single-node Ubuntu virtual machines with modest resource allocations and a lightweight DNS workload, not on production telecom infrastructure. kind is only a cloud-like stand-in, not a full public-cloud Kubernetes service, and K3s is an edge-like stand-in rather than a geographically distributed real edge deployment. Therefore, the findings are best understood as a controlled coursework comparison of Kubernetes environments for a lightweight telecom-style VNF, rather than as a universal statement about all cloud and edge systems.

## 7. Code, Scripts, and GenAI Troubleshooting

The submission package includes the manifests, setup scripts, benchmark client, metrics collection scripts, result-processing scripts, gradescope answer drafts, and documentation needed to reproduce the work. In line with the module's AMBER policy, GenAI was used only in an assistive troubleshooting role when something was not working as expected. It was used to help clarify faults and suggest debugging checks for issues such as the kind context-name mismatch, K3s kubeconfig permission handling, and the initial cloud-side resource-monitoring failure. Those suggestions were then applied, tested, and verified through my own deployment and benchmark reruns. GenAI was not used as a substitute for implementation or experimental evidence, and the final deployment steps, validation logic, benchmark execution, and submission decisions remained my own responsibility. The detailed disclosure is recorded in `GenAI troubleshooting.md` as part of the material submission.

## 8. Limitations

This coursework design intentionally uses single-node lab environments. As a result, the findings should be interpreted as a controlled comparison of orchestration overhead and deployment practicality rather than as a full telco-grade scalability study. The benchmark focuses on application-level DNS request behaviour, not on complex packet-processing or multi-function service chains. These limitations are acceptable for the assignment because they keep the scope defensible, measurable, and reproducible, and because the wider container-performance literature also cautions against over-generalising from one platform configuration to all edge and cloud deployments [7]-[9].

## 9. Conclusion

This coursework provided a controlled comparison of Kubernetes support for a lightweight telecom-relevant DNS VNF in cloud-like and edge-like environments. The same CoreDNS-based VNF was deployed successfully in both a Docker-backed kind cluster and a K3s cluster running on matched Ubuntu virtual machines. Functional validation succeeded in both cases, and the benchmark suite completed with 100% successful DNS queries across all tested scenarios.

The most important result is that both environments were operationally viable, but the edge-like K3s deployment consistently achieved lower average latency and more stable tail latency than the cloud-like kind deployment. The difference was especially clear under burst traffic, where kind experienced substantial latency inflation and severe outliers, while K3s remained much more stable. Resource usage stayed modest in both environments, which reinforces the conclusion that the main distinction was orchestration behaviour and latency stability rather than simple CoreDNS resource exhaustion. These findings suggest that for this lightweight DNS VNF and under the tested lab conditions, an edge-like K3s deployment is particularly attractive when latency sensitivity is a priority.

At the same time, the cloud-like kind environment still showed strong functional reliability and full workload completion, which means it remains a valid deployment platform for the same VNF. Overall, the coursework demonstrates that Kubernetes portability can be preserved across cloud-like and edge-like settings, but that the chosen distribution can still materially affect latency behaviour and practical deployment experience.

## References

[1] Kubernetes Authors, "Kubernetes Documentation." Available: https://kubernetes.io/docs/ (accessed 2026-03-18).

[2] Kubernetes Authors, "kind - Quick Start." Available: https://kind.sigs.k8s.io/docs/user/quick-start/ (accessed 2026-03-18).

[3] SUSE, "K3s Quick-Start Guide." Available: https://docs.k3s.io/quick-start (accessed 2026-03-18).

[4] CoreDNS Authors, "CoreDNS: DNS and Service Discovery." Available: https://coredns.io/manual/plugins/ (accessed 2026-03-18).

[5] CoreDNS Authors, "CoreDNS Hosts Plugin." Available: https://coredns.io/plugins/hosts/ (accessed 2026-03-18).

[6] Kubernetes SIGs, "metrics-server." Available: https://github.com/kubernetes-sigs/metrics-server (accessed 2026-03-18).

[7] "A Performance Evaluation of Containers Running on Managed Kubernetes Services," IEEE Xplore, 2020. Available: https://ieeexplore.ieee.org/document/8968907 (accessed 2026-03-18).

[8] "A Comprehensive Performance Evaluation of Different Kubernetes CNI Plugins for Edge-based and Containerized Publish/Subscribe Applications," IEEE Xplore, 2021. Available: https://ieeexplore.ieee.org/document/9610274/ (accessed 2026-03-18).

[9] "A Measurement Study on Evaluating Container Network Performance for Edge Computing," IEEE Xplore, 2020. Available: https://ieeexplore.ieee.org/document/9236997/ (accessed 2026-03-18).
