# Architecture Notes

## Goal

Deploy the same experimental DNS VNF on a cloud-like Kubernetes environment and an edge-like Kubernetes environment, then benchmark the two deployments using identical traffic logic.

## Logical layout

```text
Cloud VM (Ubuntu 22.04.5 LTS, ARM64)       Edge VM (Ubuntu 22.04.5 LTS, ARM64)
-------------------------------------       ------------------------------------
kind single-node cluster                    K3s single-node cluster
  telecom-dns namespace                       telecom-dns namespace
    coredns-vnf pod                             coredns-vnf pod
    coredns-vnf service                         coredns-vnf service
    dns-test-client pod                         dns-test-client pod
    dns-benchmark-runner pod                    dns-benchmark-runner pod

Benchmark traffic:
  benchmark runner -> CoreDNS service on UDP/TCP 53

Validation traffic:
  busybox nslookup -> CoreDNS service

Monitoring path:
  host kubectl top -> coredns-vnf pod

Output path:
  raw JSON/CSV -> processed CSV -> figures/tables -> report answers
```

## Why CoreDNS is a good fit here

CoreDNS is a practical VNF for this coursework because it is container-native, resource-light, and easy to exercise with realistic request/response traffic. It also allows the service function to be isolated from the cluster-default DNS by deploying a separate namespace, service, and configuration.

## Why the runner pod is separated from the test pod

The BusyBox pod is used for simple `nslookup` validation because it is lightweight and easy to understand in a demo. The Python benchmark runner is separate so that the load-generation logic can remain stable and scriptable without depending on additional packages inside BusyBox.

## Fairness decisions

- One CoreDNS replica in both environments
- Same CoreDNS image tag in both environments
- Same ConfigMap and DNS records in both environments
- Same benchmark profiles and repeat count in both environments
- Same cloned VM size and Ubuntu 22.04.5 LTS base image
- K3s extras such as Traefik and ServiceLB disabled to reduce non-essential background noise
