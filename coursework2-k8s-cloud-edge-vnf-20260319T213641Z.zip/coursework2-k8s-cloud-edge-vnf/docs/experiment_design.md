# Experiment Design

## Research question

How does the same lightweight DNS VNF behave when deployed on a cloud-like Kubernetes environment based on kind and on an edge-like Kubernetes environment based on K3s, under matched VM and workload conditions?

## Controlled variables

- Ubuntu 22.04.5 LTS on both VMs
- Same ARM64 VM size on both sides: 2 vCPU, 4 GB RAM, 20 GB disk
- Same CoreDNS image and manifest
- Same DNS records and namespace
- Same benchmark client code
- Same scenario durations, offered load, and repeat count
- Same measurement pipeline for CPU, memory, latency, throughput, and success rate

## Independent variable

The Kubernetes distribution:

- `kind` as the cloud-like environment
- `K3s` as the edge-like environment

## Dependent variables

- Query latency
- Achieved query rate
- Success and failure rate
- CPU usage of the CoreDNS VNF pod
- Memory usage of the CoreDNS VNF pod
- Setup and deployment complexity

## Scenarios

| Category | Scenario | Goal | QPS | Concurrency | Duration |
| --- | --- | --- | ---: | ---: | ---: |
| Baseline | `baseline` | Confirm correctness and estimate single-query latency | 1 | 1 | 30 s |
| Sustained | `sustained_low` | Light offered load | 20 | 2 | 60 s |
| Sustained | `sustained_medium` | Moderate offered load | 100 | 4 | 60 s |
| Sustained | `sustained_high` | Higher offered load near lab saturation | 200 | 8 | 60 s |
| Burst | `burst` | Short spike and responsiveness check | 400 | 16 | 15 s |

All scenarios are repeated three times by default.

## Measurement method

For each run:

1. Warm up the benchmark runner.
2. Execute the benchmark client from inside the cluster.
3. Sample `kubectl top pod` at a fixed interval during the benchmark.
4. Store JSON summary, per-request CSV, and metrics CSV under `results/raw/`.
5. Aggregate repeated runs into processed CSV files.
6. Generate comparison figures and tables.

## Threats to validity

- Single-node lab clusters do not represent production-grade telco deployments.
- kind runs Kubernetes nodes inside Docker containers, which adds a different packaging model from K3s.
- `kubectl top` is useful for lightweight measurement but is not a full observability stack.
- DNS is a lightweight VNF, so the findings should not be over-generalised to heavy packet-processing functions.

These limitations should be stated explicitly in the final report.
