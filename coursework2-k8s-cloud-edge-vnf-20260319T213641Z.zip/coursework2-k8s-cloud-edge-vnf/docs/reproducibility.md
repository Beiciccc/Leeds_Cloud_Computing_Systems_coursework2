# Reproducibility Notes

## Intended execution environment

- Ubuntu 22.04.5 LTS for both VMs
- ARM64 / aarch64 for both VMs
- 2 vCPU and 4 GB RAM on both VMs
- 20 GB virtual disk on both VMs, with about 19 GiB in the root filesystem
- Both VMs cloned from the same base image
- Single-node kind cluster on the cloud-like VM
- Single-node K3s cluster on the edge-like VM

## Reproducibility checklist

1. Keep the same VM size on both sides.
2. Run benchmarks when the VMs are otherwise idle.
3. Use the same repository revision in both environments.
4. Use the same CoreDNS image tag and manifests.
5. Do not modify benchmark profiles between the two environments.
6. Repeat each scenario the same number of times.
7. Keep raw outputs unchanged once captured.
8. Generate processed CSV files and figures from those raw outputs.

## Evidence to capture during execution

- `kubectl get nodes -o wide`
- `kubectl get pods -n telecom-dns -o wide`
- `kubectl get svc -n telecom-dns`
- Hello-world `nslookup` output
- Raw benchmark summaries and per-request samples
- `kubectl top` CSV outputs
- Final processed tables and figures

## What must be edited after execution

- `REPORT_DRAFT.md`
- `gradescope_answers/Q5_results_and_discussion.txt`
- `GenAI troubleshooting.md`
- `results/tables/environment_summary.md`
- `results/tables/deployment_complexity.md`
