# Literature Notes

## Positioning

The coursework combines two strands of literature and practice:

1. Official platform documentation on Kubernetes, kind, K3s, CoreDNS, and metrics-server.
2. Representative performance studies on containers, Kubernetes networking, and edge-oriented deployments.

The report should use the official documentation for implementation details and a small number of papers for context, rather than claiming broad telco conclusions from a single lab experiment.

## Practical sources used in this project

- Kubernetes documentation for general cluster concepts and resource metrics pipeline.
- kind documentation for the cloud-like local Kubernetes environment.
- K3s documentation for lightweight edge-oriented Kubernetes deployment.
- CoreDNS plugin documentation, especially the `hosts` plugin used for fixed A-record responses.
- metrics-server documentation for lightweight CPU and memory collection via `kubectl top`.

## Related-work angle for the report

Useful framing points:

- Kubernetes is widely adopted as a control plane for containerised workloads, including network-facing services.
- Edge deployments prioritise small operational footprints and low management overhead.
- Performance evaluation in small clusters should consider both application behaviour and orchestration overhead.
- DNS is narrower than a full 5G control plane, but it is still a legitimate network function because service discovery is operationally important in distributed environments.

## Writing advice

- Avoid pretending that this experiment proves edge superiority or cloud superiority in general.
- Focus on what was directly measured: latency, throughput, success rate, CPU, memory, and setup complexity.
- Use the literature to motivate the experiment and interpret the observed trend, not to replace evidence.

## Candidate references

See `references/references.bib` for the entries prepared for this coursework package.

