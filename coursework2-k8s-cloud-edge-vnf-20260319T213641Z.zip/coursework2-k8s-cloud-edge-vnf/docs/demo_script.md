# Demo Script Notes

## Objective

Show, in under two minutes, that the same telecom-style DNS VNF was deployed on kind and K3s, validated with a hello-world DNS query, and benchmarked with a repeatable measurement pipeline.

## Suggested screen order

1. Show the repository root and briefly state the objective.
2. Show `kubectl config get-contexts` or equivalent evidence that both kind and K3s are available.
3. Show `kubectl get pods -n telecom-dns` for kind.
4. Show the same for K3s.
5. Run or display a saved `nslookup ue1.telecom.local ...` validation result.
6. Show one benchmark command or saved run directory.
7. Show the generated latency/throughput/resource figures.
8. End with one sentence comparing the cloud-like and edge-like environments.

## Spoken emphasis

- Same VNF in both environments
- Same benchmark logic in both environments
- Small, defensible lab-scale DNS VNF
- No fabricated results; figures come from the generated pipeline

