#!/usr/bin/env python3
"""Lightweight DNS benchmark client using only the Python standard library."""

from __future__ import annotations

import argparse
import csv
import json
import random
import socket
import statistics
import struct
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import List


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def encode_qname(name: str) -> bytes:
    labels = [label for label in name.strip(".").split(".") if label]
    return b"".join(len(label).to_bytes(1, "big") + label.encode("ascii") for label in labels) + b"\x00"


def build_query(query_id: int, qname: str, qtype: int = 1) -> bytes:
    header = struct.pack("!HHHHHH", query_id, 0x0100, 1, 0, 0, 0)
    question = encode_qname(qname) + struct.pack("!HH", qtype, 1)
    return header + question


def skip_name(message: bytes, offset: int) -> int:
    while True:
        if offset >= len(message):
            raise ValueError("Truncated DNS message while parsing name")
        length = message[offset]
        if length == 0:
            return offset + 1
        if length & 0xC0 == 0xC0:
            return offset + 2
        offset += 1 + length


def parse_response(message: bytes, expected_id: int) -> dict:
    if len(message) < 12:
      raise ValueError("DNS response shorter than header")
    response_id, flags, qdcount, ancount, _, _ = struct.unpack("!HHHHHH", message[:12])
    if response_id != expected_id:
        raise ValueError(f"DNS transaction ID mismatch: expected {expected_id}, got {response_id}")
    rcode = flags & 0x000F
    qr = (flags >> 15) & 0x0001
    if qr != 1:
        raise ValueError("Received packet is not a DNS response")
    offset = 12
    for _ in range(qdcount):
        offset = skip_name(message, offset)
        offset += 4
    answers = []
    for _ in range(ancount):
        offset = skip_name(message, offset)
        if offset + 10 > len(message):
            raise ValueError("Truncated DNS answer header")
        rtype, _, _, rdlength = struct.unpack("!HHIH", message[offset:offset + 10])
        offset += 10
        if offset + rdlength > len(message):
            raise ValueError("Truncated DNS rdata section")
        rdata = message[offset:offset + rdlength]
        offset += rdlength
        if rtype == 1 and rdlength == 4:
            answers.append(socket.inet_ntoa(rdata))
    return {"rcode": rcode, "answer_count": ancount, "answers": answers}


def percentile(values: List[float], pct: float) -> float:
    if not values:
        return 0.0
    if len(values) == 1:
        return values[0]
    ordered = sorted(values)
    index = (len(ordered) - 1) * pct
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    if lower == upper:
        return ordered[lower]
    fraction = index - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * fraction


@dataclass
class RequestResult:
    sequence: int
    timestamp_utc: str
    qname: str
    latency_ms: float
    success: bool
    rcode: int
    answer_count: int
    answers: str
    error: str


class Scheduler:
    def __init__(self, start_monotonic: float, qps: float, total_requests: int) -> None:
        self.start_monotonic = start_monotonic
        self.qps = qps
        self.total_requests = total_requests
        self._lock = threading.Lock()
        self._index = 0

    def next_slot(self) -> tuple[int, float] | None:
        with self._lock:
            if self._index >= self.total_requests:
                return None
            sequence = self._index
            self._index += 1
        scheduled = self.start_monotonic + (sequence / self.qps)
        return sequence, scheduled


def run_udp_query(server: str, port: int, timeout: float, qname: str, query_id: int, sock: socket.socket) -> tuple[float, dict]:
    payload = build_query(query_id, qname)
    started = time.perf_counter_ns()
    sock.sendto(payload, (server, port))
    response, _ = sock.recvfrom(4096)
    finished = time.perf_counter_ns()
    parsed = parse_response(response, query_id)
    latency_ms = (finished - started) / 1_000_000
    return latency_ms, parsed


def run_tcp_query(server: str, port: int, timeout: float, qname: str, query_id: int) -> tuple[float, dict]:
    payload = build_query(query_id, qname)
    wire = struct.pack("!H", len(payload)) + payload
    started = time.perf_counter_ns()
    with socket.create_connection((server, port), timeout=timeout) as conn:
        conn.sendall(wire)
        length_data = conn.recv(2)
        if len(length_data) != 2:
            raise ValueError("Truncated TCP DNS length prefix")
        response_length = struct.unpack("!H", length_data)[0]
        response = b""
        while len(response) < response_length:
            chunk = conn.recv(response_length - len(response))
            if not chunk:
                break
            response += chunk
    finished = time.perf_counter_ns()
    if len(response) != response_length:
        raise ValueError("Incomplete TCP DNS response payload")
    parsed = parse_response(response, query_id)
    latency_ms = (finished - started) / 1_000_000
    return latency_ms, parsed


def worker(worker_id: int, args: argparse.Namespace, scheduler: Scheduler, names: List[str], results: List[RequestResult], results_lock: threading.Lock) -> None:
    udp_socket = None
    if args.protocol == "udp":
        udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_socket.settimeout(args.timeout)
    try:
        while True:
            slot = scheduler.next_slot()
            if slot is None:
                return
            sequence, scheduled = slot
            while True:
                now = time.perf_counter()
                remaining = scheduled - now
                if remaining <= 0:
                    break
                time.sleep(min(remaining, 0.005))
            qname = names[sequence % len(names)]
            query_id = random.getrandbits(16)
            success = False
            latency_ms = 0.0
            rcode = -1
            answer_count = 0
            answers = ""
            error = ""
            try:
                if args.protocol == "udp":
                    latency_ms, parsed = run_udp_query(args.server, args.port, args.timeout, qname, query_id, udp_socket)  # type: ignore[arg-type]
                else:
                    latency_ms, parsed = run_tcp_query(args.server, args.port, args.timeout, qname, query_id)
                rcode = int(parsed["rcode"])
                answer_count = int(parsed["answer_count"])
                answers = ";".join(parsed["answers"])
                success = rcode == 0 and answer_count > 0
                if not success and not answers:
                    error = f"rcode={rcode}"
            except Exception as exc:  # noqa: BLE001
                error = str(exc)
            with results_lock:
                results.append(
                    RequestResult(
                        sequence=sequence,
                        timestamp_utc=utc_now(),
                        qname=qname,
                        latency_ms=round(latency_ms, 6),
                        success=success,
                        rcode=rcode,
                        answer_count=answer_count,
                        answers=answers,
                        error=error,
                    )
                )
    finally:
        if udp_socket is not None:
            udp_socket.close()


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a lightweight DNS latency and throughput benchmark.")
    parser.add_argument("--server", required=True, help="DNS server hostname or IP address")
    parser.add_argument("--port", type=int, default=53, help="DNS server port")
    parser.add_argument("--protocol", choices=["udp", "tcp"], default="udp", help="Transport protocol")
    parser.add_argument("--qnames", required=True, help="Comma-separated list of query names")
    parser.add_argument("--duration", type=float, required=True, help="Measured benchmark duration in seconds")
    parser.add_argument("--warmup", type=float, default=0.0, help="Warm-up period in seconds before measurements")
    parser.add_argument("--qps", type=float, required=True, help="Target offered query rate")
    parser.add_argument("--concurrency", type=int, default=1, help="Number of worker threads")
    parser.add_argument("--timeout", type=float, default=2.0, help="Socket timeout in seconds")
    parser.add_argument("--scenario", default="unspecified", help="Experiment scenario label")
    parser.add_argument("--environment", default="unspecified", help="Environment label")
    parser.add_argument("--output-summary", required=True, help="Path to JSON summary output")
    parser.add_argument("--output-samples", required=True, help="Path to CSV per-request output")
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    if args.qps <= 0:
        raise SystemExit("--qps must be greater than zero")
    if args.duration <= 0:
        raise SystemExit("--duration must be greater than zero")
    if args.concurrency <= 0:
        raise SystemExit("--concurrency must be greater than zero")

    names = [name.strip() for name in args.qnames.split(",") if name.strip()]
    if not names:
        raise SystemExit("At least one query name must be provided")

    total_requests = max(1, int(round(args.qps * args.duration)))
    time.sleep(args.warmup)

    started_at = utc_now()
    start_monotonic = time.perf_counter()
    scheduler = Scheduler(start_monotonic, args.qps, total_requests)
    results: List[RequestResult] = []
    results_lock = threading.Lock()
    threads = []
    for worker_id in range(args.concurrency):
        thread = threading.Thread(target=worker, args=(worker_id, args, scheduler, names, results, results_lock), daemon=True)
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join()
    finished_at = utc_now()
    elapsed = max(time.perf_counter() - start_monotonic, 0.001)

    ordered_results = sorted(results, key=lambda item: item.sequence)
    latencies = [item.latency_ms for item in ordered_results if item.success]
    success_count = sum(1 for item in ordered_results if item.success)
    failure_count = len(ordered_results) - success_count

    summary = {
        "environment": args.environment,
        "scenario": args.scenario,
        "server": args.server,
        "port": args.port,
        "protocol": args.protocol,
        "duration_seconds": args.duration,
        "warmup_seconds": args.warmup,
        "requested_qps": args.qps,
        "concurrency": args.concurrency,
        "total_requests": len(ordered_results),
        "successful_requests": success_count,
        "failed_requests": failure_count,
        "success_rate_pct": round((success_count / len(ordered_results) * 100.0) if ordered_results else 0.0, 4),
        "achieved_qps": round(len(ordered_results) / elapsed, 4),
        "latency_ms_avg": round(statistics.fmean(latencies), 6) if latencies else 0.0,
        "latency_ms_p50": round(percentile(latencies, 0.50), 6) if latencies else 0.0,
        "latency_ms_p95": round(percentile(latencies, 0.95), 6) if latencies else 0.0,
        "latency_ms_p99": round(percentile(latencies, 0.99), 6) if latencies else 0.0,
        "latency_ms_min": round(min(latencies), 6) if latencies else 0.0,
        "latency_ms_max": round(max(latencies), 6) if latencies else 0.0,
        "started_at_utc": started_at,
        "finished_at_utc": finished_at,
    }

    summary_path = Path(args.output_summary)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    samples_path = Path(args.output_samples)
    samples_path.parent.mkdir(parents=True, exist_ok=True)
    with samples_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["sequence", "timestamp_utc", "qname", "latency_ms", "success", "rcode", "answer_count", "answers", "error"])
        for item in ordered_results:
            writer.writerow(
                [
                    item.sequence,
                    item.timestamp_utc,
                    item.qname,
                    f"{item.latency_ms:.6f}",
                    str(item.success).lower(),
                    item.rcode,
                    item.answer_count,
                    item.answers,
                    item.error,
                ]
            )

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

