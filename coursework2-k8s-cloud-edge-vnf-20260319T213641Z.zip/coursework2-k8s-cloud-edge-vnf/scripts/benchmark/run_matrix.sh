#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

TARGET="${1:-}"
OVERRIDE_REPEATS="${2:-}"
PROFILE_FILE="${REPO_ROOT}/scripts/benchmark/experiment_profiles.csv"

if [[ -z "${TARGET}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context> [repeat-count]" >&2
  exit 1
fi

"${REPO_ROOT}/scripts/deploy/deploy_vnf.sh" "${TARGET}"
"${REPO_ROOT}/scripts/test/capture_cluster_state.sh" "${TARGET}"
"${REPO_ROOT}/scripts/test/hello_world.sh" "${TARGET}"

tail -n +2 "${PROFILE_FILE}" | while IFS=, read -r scenario _qps _concurrency _duration _warmup default_repeats _description; do
  repeat_total="${OVERRIDE_REPEATS:-${default_repeats:-${DEFAULT_REPEAT_COUNT}}}"
  for repeat_index in $(seq 1 "${repeat_total}"); do
    "${REPO_ROOT}/scripts/benchmark/run_experiment.sh" "${TARGET}" "${scenario}" "${repeat_index}"
  done
done

