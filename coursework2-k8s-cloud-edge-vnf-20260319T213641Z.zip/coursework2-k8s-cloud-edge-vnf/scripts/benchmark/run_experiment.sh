#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl
require_cmd awk

TARGET="${1:-}"
SCENARIO="${2:-}"
REPEAT_INDEX="${3:-1}"

if [[ -z "${TARGET}" || -z "${SCENARIO}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context> <scenario> [repeat-index]" >&2
  exit 1
fi

PROFILE_FILE="${REPO_ROOT}/scripts/benchmark/experiment_profiles.csv"
profile_line="$(awk -F, -v scenario="${SCENARIO}" 'NR > 1 && $1 == scenario { print $0 }' "${PROFILE_FILE}")"
if [[ -z "${profile_line}" ]]; then
  echo "Scenario ${SCENARIO} was not found in ${PROFILE_FILE}" >&2
  exit 1
fi

IFS=, read -r _scenario qps concurrency duration_seconds warmup_seconds default_repeats description <<< "${profile_line}"
CONTEXT="$(resolve_context "${TARGET}")"
ENV_NAME="$(resolve_environment_name "${TARGET}")"
RUN_DIR="${RESULTS_DIR}/raw/${ENV_NAME}/${SCENARIO}/run$(printf '%02d' "${REPEAT_INDEX}")"
METRICS_PATH="${RUN_DIR}/metrics.csv"
SUMMARY_REMOTE="/tmp/${SCENARIO}_summary.json"
SAMPLES_REMOTE="/tmp/${SCENARIO}_samples.csv"
RUNNER="deployment/${RUNNER_DEPLOYMENT}"

ensure_dir "${RUN_DIR}"

command_string="python /bench/dns_benchmark.py --server ${BENCHMARK_SERVER} --port ${BENCHMARK_PORT} --protocol udp --qnames ${BENCHMARK_NAMES} --duration ${duration_seconds} --warmup ${warmup_seconds} --qps ${qps} --concurrency ${concurrency} --timeout ${BENCHMARK_TIMEOUT_SECONDS} --scenario ${SCENARIO} --environment ${ENV_NAME} --output-summary ${SUMMARY_REMOTE} --output-samples ${SAMPLES_REMOTE}"
printf '%s\n' "${command_string}" > "${RUN_DIR}/command.txt"
printf '%s\n' "${description}" > "${RUN_DIR}/description.txt"

metrics_duration="$(python3 - <<PY
duration = float(${duration_seconds}) + float(${warmup_seconds}) + 5.0
print(int(duration))
PY
)"

"${REPO_ROOT}/scripts/metrics/sample_kubectl_top.sh" "${CONTEXT}" "${metrics_duration}" "${METRICS_PATH}" &
sampler_pid=$!

kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" exec "${RUNNER}" -- sh -c "rm -f '${SUMMARY_REMOTE}' '${SAMPLES_REMOTE}' && ${command_string}" | tee "${RUN_DIR}/benchmark_stdout.json"

wait "${sampler_pid}"

kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" exec "${RUNNER}" -- cat "${SUMMARY_REMOTE}" > "${RUN_DIR}/summary.json"
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" exec "${RUNNER}" -- cat "${SAMPLES_REMOTE}" > "${RUN_DIR}/samples.csv"
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" get pods -o wide > "${RUN_DIR}/pod_snapshot.txt"

echo "Completed ${ENV_NAME}/${SCENARIO}/run$(printf '%02d' "${REPEAT_INDEX}")"

