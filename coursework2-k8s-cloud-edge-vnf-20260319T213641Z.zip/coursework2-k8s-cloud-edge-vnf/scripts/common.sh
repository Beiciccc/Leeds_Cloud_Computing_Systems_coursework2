#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
RESULTS_DIR="${REPO_ROOT}/results"
NAMESPACE="${NAMESPACE:-telecom-dns}"
VNF_APP_LABEL="${VNF_APP_LABEL:-app.kubernetes.io/name=coredns-vnf}"
RUNNER_DEPLOYMENT="${RUNNER_DEPLOYMENT:-dns-benchmark-runner}"
RUNNER_POD_LABEL="${RUNNER_POD_LABEL:-app.kubernetes.io/name=dns-benchmark-runner}"
SERVICE_NAME="${SERVICE_NAME:-coredns-vnf}"
KIND_CONTEXT="${KIND_CONTEXT:-kind-comp5123m-cloud}"
K3S_CONTEXT="${K3S_CONTEXT:-comp5123m-edge}"
DEFAULT_REPEAT_COUNT="${DEFAULT_REPEAT_COUNT:-3}"
BENCHMARK_SERVER="${BENCHMARK_SERVER:-coredns-vnf.telecom-dns.svc.cluster.local}"
BENCHMARK_PORT="${BENCHMARK_PORT:-53}"
BENCHMARK_NAMES="${BENCHMARK_NAMES:-ue1.telecom.local,upf.telecom.local,amf.telecom.local,edge-cache.telecom.local}"
BENCHMARK_TIMEOUT_SECONDS="${BENCHMARK_TIMEOUT_SECONDS:-2.0}"
METRICS_INTERVAL_SECONDS="${METRICS_INTERVAL_SECONDS:-2}"

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Missing required command: $1" >&2
    exit 1
  fi
}

resolve_context() {
  case "${1:-}" in
    kind|cloud)
      printf '%s\n' "${KIND_CONTEXT}"
      ;;
    k3s|edge)
      printf '%s\n' "${K3S_CONTEXT}"
      ;;
    *)
      printf '%s\n' "${1:-}"
      ;;
  esac
}

resolve_environment_name() {
  case "${1:-}" in
    "${KIND_CONTEXT}"|kind|cloud|kind-cloud)
      printf 'kind-cloud\n'
      ;;
    "${K3S_CONTEXT}"|k3s|edge|default|k3s-edge)
      printf 'k3s-edge\n'
      ;;
    *)
      printf '%s\n' "${1:-unknown}"
      ;;
  esac
}

kubectl_ctx() {
  local context="$1"
  shift
  kubectl --context "${context}" "$@"
}

timestamp_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

ensure_dir() {
  mkdir -p "$1"
}

runner_pod_name() {
  local context="$1"
  kubectl_ctx "${context}" -n "${NAMESPACE}" get pods -l "${RUNNER_POD_LABEL}" -o jsonpath='{.items[0].metadata.name}'
}
