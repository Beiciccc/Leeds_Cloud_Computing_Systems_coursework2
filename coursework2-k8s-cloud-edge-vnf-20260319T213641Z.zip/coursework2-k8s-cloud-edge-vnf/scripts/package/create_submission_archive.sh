#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd rsync
require_cmd tar

ARCHIVE_NAME="${ARCHIVE_NAME:-coursework2-k8s-cloud-edge-vnf}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DIST_DIR="${REPO_ROOT}/dist"
STAGING_DIR="${DIST_DIR}/${ARCHIVE_NAME}"

mkdir -p "${DIST_DIR}"
rm -rf "${STAGING_DIR}"

rsync -a \
  --exclude '.git' \
  --exclude 'dist' \
  --exclude '__pycache__' \
  --exclude '.DS_Store' \
  --exclude 'GRADESCOPE_SUBMISSION_GUIDE.md' \
  --exclude 'SUBMISSION_CHECKLIST.md' \
  "${REPO_ROOT}/" "${STAGING_DIR}/"

tar -czf "${DIST_DIR}/${ARCHIVE_NAME}-${STAMP}.tar.gz" -C "${DIST_DIR}" "${ARCHIVE_NAME}"

if command -v zip >/dev/null 2>&1; then
  (
    cd "${DIST_DIR}"
    rm -f "${ARCHIVE_NAME}-${STAMP}.zip"
    zip -qr "${ARCHIVE_NAME}-${STAMP}.zip" "${ARCHIVE_NAME}"
  )
fi

echo "Created submission archive(s) in ${DIST_DIR}"
