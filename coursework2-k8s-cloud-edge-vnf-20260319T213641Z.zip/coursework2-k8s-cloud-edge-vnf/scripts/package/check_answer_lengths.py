#!/usr/bin/env python3
"""Validate the character limits for Gradescope answer drafts."""

from __future__ import annotations

from pathlib import Path


LIMITS = {
    "Q1_general_information.txt": 400,
    "Q2_selection_and_justification.txt": 2500,
    "Q3_environment_setup_and_deployment.txt": 2500,
    "Q4_experimental_design_and_monitoring.txt": 2500,
    "Q5_results_and_discussion.txt": 3000,
}


def main() -> None:
    repo_root = Path(__file__).resolve().parents[2]
    answers_root = repo_root / "gradescope_answers"
    failures = []

    for filename, limit in LIMITS.items():
      path = answers_root / filename
      content = path.read_text(encoding="utf-8").strip()
      length = len(content)
      print(f"{filename}: {length}/{limit} characters")
      if length > limit:
          failures.append(f"{filename} exceeds the limit by {length - limit} characters")

    if failures:
        raise SystemExit("\n".join(failures))


if __name__ == "__main__":
    main()

