#!/usr/bin/env python3
"""Aggregate benchmark summaries and kubectl top samples into processed CSV files."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
from statistics import fmean
from typing import Dict, Iterable, List


NUMERIC_FIELDS = [
    "duration_seconds",
    "warmup_seconds",
    "requested_qps",
    "concurrency",
    "total_requests",
    "successful_requests",
    "failed_requests",
    "success_rate_pct",
    "achieved_qps",
    "latency_ms_avg",
    "latency_ms_p50",
    "latency_ms_p95",
    "latency_ms_p99",
    "latency_ms_min",
    "latency_ms_max",
]


def parse_cpu_to_millicores(value: str) -> float:
    value = value.strip()
    if value in {"", "NA"}:
        return 0.0
    if value.endswith("m"):
        return float(value[:-1])
    return float(value) * 1000.0


def parse_memory_to_mib(value: str) -> float:
    value = value.strip()
    if value in {"", "NA"}:
        return 0.0
    units = {
        "Ki": 1 / 1024,
        "Mi": 1.0,
        "Gi": 1024.0,
        "Ti": 1024.0 * 1024.0,
        "K": 1 / 1000 / 1024,
        "M": 1 / 1024,
        "G": 1000 / 1024,
    }
    for suffix, factor in units.items():
        if value.endswith(suffix):
            return float(value[: -len(suffix)]) * factor
    return float(value) / (1024 * 1024)


def summarise_metrics(metrics_path: Path) -> Dict[str, float]:
    if not metrics_path.exists():
      return {
          "metrics_samples": 0,
          "avg_cpu_millicores": 0.0,
          "peak_cpu_millicores": 0.0,
          "avg_memory_mib": 0.0,
          "peak_memory_mib": 0.0,
      }

    cpu_samples: List[float] = []
    memory_samples: List[float] = []
    with metrics_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            if row["pod"] == "NO_DATA":
                continue
            cpu_samples.append(parse_cpu_to_millicores(row["cpu_raw"]))
            memory_samples.append(parse_memory_to_mib(row["memory_raw"]))
    return {
        "metrics_samples": len(cpu_samples),
        "avg_cpu_millicores": round(fmean(cpu_samples), 6) if cpu_samples else 0.0,
        "peak_cpu_millicores": round(max(cpu_samples), 6) if cpu_samples else 0.0,
        "avg_memory_mib": round(fmean(memory_samples), 6) if memory_samples else 0.0,
        "peak_memory_mib": round(max(memory_samples), 6) if memory_samples else 0.0,
    }


def mean(values: Iterable[float]) -> float:
    values = list(values)
    return round(fmean(values), 6) if values else 0.0


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def aggregate(results_root: Path) -> None:
    raw_root = results_root / "raw"
    processed_root = results_root / "processed"
    benchmark_rows: List[Dict[str, object]] = []

    for summary_path in sorted(raw_root.rglob("summary.json")):
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        relative = summary_path.relative_to(raw_root)
        parts = relative.parts
        if len(parts) < 4:
            continue
        environment, scenario, run_name = parts[0], parts[1], parts[2]
        row = {
            "environment": environment,
            "scenario": scenario,
            "run": run_name,
        }
        row.update(summary)
        row.update(summarise_metrics(summary_path.with_name("metrics.csv")))
        benchmark_rows.append(row)

    benchmark_fieldnames = [
        "environment",
        "scenario",
        "run",
        "server",
        "port",
        "protocol",
        "duration_seconds",
        "warmup_seconds",
        "requested_qps",
        "concurrency",
        "total_requests",
        "successful_requests",
        "failed_requests",
        "success_rate_pct",
        "achieved_qps",
        "latency_ms_avg",
        "latency_ms_p50",
        "latency_ms_p95",
        "latency_ms_p99",
        "latency_ms_min",
        "latency_ms_max",
        "metrics_samples",
        "avg_cpu_millicores",
        "peak_cpu_millicores",
        "avg_memory_mib",
        "peak_memory_mib",
        "started_at_utc",
        "finished_at_utc",
    ]
    write_csv(processed_root / "benchmark_runs.csv", benchmark_rows, benchmark_fieldnames)

    grouped: Dict[tuple[str, str], List[Dict[str, object]]] = defaultdict(list)
    for row in benchmark_rows:
        grouped[(str(row["environment"]), str(row["scenario"]))].append(row)

    scenario_rows: List[Dict[str, object]] = []
    for (environment, scenario), rows in sorted(grouped.items()):
        aggregate_row: Dict[str, object] = {
            "environment": environment,
            "scenario": scenario,
            "repeats": len(rows),
        }
        for key in NUMERIC_FIELDS:
            aggregate_row[f"{key}_mean"] = mean(float(row.get(key, 0.0)) for row in rows)
        for key in ["avg_cpu_millicores", "peak_cpu_millicores", "avg_memory_mib", "peak_memory_mib"]:
            aggregate_row[f"{key}_mean"] = mean(float(row.get(key, 0.0)) for row in rows)
        scenario_rows.append(aggregate_row)

    scenario_fieldnames = [
        "environment",
        "scenario",
        "repeats",
        "duration_seconds_mean",
        "warmup_seconds_mean",
        "requested_qps_mean",
        "concurrency_mean",
        "total_requests_mean",
        "successful_requests_mean",
        "failed_requests_mean",
        "success_rate_pct_mean",
        "achieved_qps_mean",
        "latency_ms_avg_mean",
        "latency_ms_p50_mean",
        "latency_ms_p95_mean",
        "latency_ms_p99_mean",
        "latency_ms_min_mean",
        "latency_ms_max_mean",
        "avg_cpu_millicores_mean",
        "peak_cpu_millicores_mean",
        "avg_memory_mib_mean",
        "peak_memory_mib_mean",
    ]
    write_csv(processed_root / "scenario_summary.csv", scenario_rows, scenario_fieldnames)

    resource_rows = [
        {
            "environment": row["environment"],
            "scenario": row["scenario"],
            "avg_cpu_millicores_mean": row["avg_cpu_millicores_mean"],
            "peak_cpu_millicores_mean": row["peak_cpu_millicores_mean"],
            "avg_memory_mib_mean": row["avg_memory_mib_mean"],
            "peak_memory_mib_mean": row["peak_memory_mib_mean"],
        }
        for row in scenario_rows
    ]
    resource_fieldnames = [
        "environment",
        "scenario",
        "avg_cpu_millicores_mean",
        "peak_cpu_millicores_mean",
        "avg_memory_mib_mean",
        "peak_memory_mib_mean",
    ]
    write_csv(processed_root / "resource_summary.csv", resource_rows, resource_fieldnames)

    print(f"Wrote processed CSV files to {processed_root}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", default="results", help="Path to the results directory")
    args = parser.parse_args()
    aggregate(Path(args.results_root))


if __name__ == "__main__":
    main()

