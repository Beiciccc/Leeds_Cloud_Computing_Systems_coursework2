#!/usr/bin/env python3
"""Generate figures and markdown tables from processed benchmark CSV files."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

try:
    import matplotlib.pyplot as plt
except ImportError as exc:  # noqa: BLE001
    raise SystemExit("matplotlib is required. Install it with: python3 -m pip install matplotlib") from exc


SCENARIO_ORDER = ["baseline", "sustained_low", "sustained_medium", "sustained_high", "burst"]


def load_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def to_float(row: dict[str, str], key: str) -> float:
    value = row.get(key, "0").strip()
    return float(value or 0.0)


def ordered_scenarios(rows: list[dict[str, str]]) -> list[str]:
    available = {row["scenario"] for row in rows}
    return [scenario for scenario in SCENARIO_ORDER if scenario in available]


def rows_for_environment(rows: list[dict[str, str]], environment: str) -> dict[str, dict[str, str]]:
    return {row["scenario"]: row for row in rows if row["environment"] == environment}


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def plot_latency(rows: list[dict[str, str]], output_path: Path) -> None:
    scenarios = ordered_scenarios(rows)
    environments = sorted({row["environment"] for row in rows})
    if not scenarios or not environments:
        return

    width = 0.35
    x_positions = list(range(len(scenarios)))

    fig, ax = plt.subplots(figsize=(10, 5))
    for index, environment in enumerate(environments):
        env_rows = rows_for_environment(rows, environment)
        values = [to_float(env_rows.get(scenario, {}), "latency_ms_avg_mean") for scenario in scenarios]
        positions = [x + (index - (len(environments) - 1) / 2) * width for x in x_positions]
        ax.bar(positions, values, width=width, label=environment)
    ax.set_title("Average DNS Query Latency")
    ax.set_ylabel("Latency (ms)")
    ax.set_xticks(x_positions)
    ax.set_xticklabels(scenarios, rotation=15)
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.3)
    fig.tight_layout()
    ensure_parent(output_path)
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_throughput(rows: list[dict[str, str]], output_path: Path) -> None:
    scenarios = ordered_scenarios(rows)
    environments = sorted({row["environment"] for row in rows})
    if not scenarios or not environments:
        return

    width = 0.35
    x_positions = list(range(len(scenarios)))

    fig, ax = plt.subplots(figsize=(10, 5))
    for index, environment in enumerate(environments):
        env_rows = rows_for_environment(rows, environment)
        values = [to_float(env_rows.get(scenario, {}), "achieved_qps_mean") for scenario in scenarios]
        positions = [x + (index - (len(environments) - 1) / 2) * width for x in x_positions]
        ax.bar(positions, values, width=width, label=environment)
    ax.set_title("Achieved Query Rate")
    ax.set_ylabel("Queries per second")
    ax.set_xticks(x_positions)
    ax.set_xticklabels(scenarios, rotation=15)
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.3)
    fig.tight_layout()
    ensure_parent(output_path)
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def plot_resource(rows: list[dict[str, str]], output_path: Path) -> None:
    scenarios = ordered_scenarios(rows)
    environments = sorted({row["environment"] for row in rows})
    if not scenarios or not environments:
        return

    width = 0.35
    x_positions = list(range(len(scenarios)))
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    for index, environment in enumerate(environments):
        env_rows = rows_for_environment(rows, environment)
        cpu_values = [to_float(env_rows.get(scenario, {}), "avg_cpu_millicores_mean") for scenario in scenarios]
        mem_values = [to_float(env_rows.get(scenario, {}), "avg_memory_mib_mean") for scenario in scenarios]
        positions = [x + (index - (len(environments) - 1) / 2) * width for x in x_positions]
        axes[0].bar(positions, cpu_values, width=width, label=environment)
        axes[1].bar(positions, mem_values, width=width, label=environment)

    axes[0].set_title("Average CPU Usage")
    axes[0].set_ylabel("millicores")
    axes[1].set_title("Average Memory Usage")
    axes[1].set_ylabel("MiB")
    for ax in axes:
        ax.set_xticks(x_positions)
        ax.set_xticklabels(scenarios, rotation=15)
        ax.grid(axis="y", linestyle="--", alpha=0.3)
        ax.legend()
    fig.tight_layout()
    ensure_parent(output_path)
    fig.savefig(output_path, dpi=200)
    plt.close(fig)


def write_markdown_table(rows: list[dict[str, str]], output_path: Path) -> None:
    if not rows:
        return
    ordered = sorted(rows, key=lambda row: (row["environment"], SCENARIO_ORDER.index(row["scenario"]) if row["scenario"] in SCENARIO_ORDER else 99))
    lines = [
        "| Environment | Scenario | Repeats | Avg latency (ms) | P95 latency (ms) | Achieved QPS | Success rate (%) | Avg CPU (m) | Avg memory (MiB) |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in ordered:
        lines.append(
            "| {environment} | {scenario} | {repeats} | {latency_ms_avg_mean} | {latency_ms_p95_mean} | {achieved_qps_mean} | {success_rate_pct_mean} | {avg_cpu_millicores_mean} | {avg_memory_mib_mean} |".format(
                **row
            )
        )
    ensure_parent(output_path)
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", default="results", help="Path to the results directory")
    args = parser.parse_args()

    results_root = Path(args.results_root)
    processed_root = results_root / "processed"
    figures_root = results_root / "figures"
    tables_root = results_root / "tables"

    rows = load_rows(processed_root / "scenario_summary.csv")
    if not rows:
        print("No processed scenario_summary.csv data found; skipping figure generation.")
        return

    plot_latency(rows, figures_root / "latency_comparison.png")
    plot_throughput(rows, figures_root / "throughput_comparison.png")
    plot_resource(rows, figures_root / "resource_comparison.png")
    write_markdown_table(rows, tables_root / "benchmark_summary.md")
    print(f"Wrote figures to {figures_root} and markdown table to {tables_root}")


if __name__ == "__main__":
    main()

