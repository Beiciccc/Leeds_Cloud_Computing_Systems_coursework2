#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl

CONTEXT="$(resolve_context "${1:-}")"
if [[ -z "${CONTEXT}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context>" >&2
  exit 1
fi

kubectl_ctx "${CONTEXT}" delete namespace "${NAMESPACE}" --ignore-not-found=true

