#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl

CONTEXT="$(resolve_context "${1:-}")"
if [[ -z "${CONTEXT}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context>" >&2
  exit 1
fi

kubectl_ctx "${CONTEXT}" create namespace "${NAMESPACE}" --dry-run=client -o yaml | kubectl_ctx "${CONTEXT}" apply -f -
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" create configmap dns-benchmark-script \
  --from-file=dns_benchmark.py="${REPO_ROOT}/scripts/benchmark/dns_benchmark.py" \
  --dry-run=client -o yaml | kubectl_ctx "${CONTEXT}" apply -f -

