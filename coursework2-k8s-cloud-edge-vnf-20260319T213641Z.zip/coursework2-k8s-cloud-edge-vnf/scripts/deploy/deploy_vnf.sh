#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl

TARGET="${1:-}"
if [[ -z "${TARGET}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context>" >&2
  exit 1
fi

CONTEXT="$(resolve_context "${TARGET}")"
ENV_NAME="$(resolve_environment_name "${TARGET}")"

if ! kubectl config get-contexts -o name | grep -qx "${CONTEXT}"; then
  echo "Context ${CONTEXT} was not found in kubeconfig." >&2
  exit 1
fi

kubectl_ctx "${CONTEXT}" apply -f "${REPO_ROOT}/manifests/common/namespace.yaml"
"${REPO_ROOT}/scripts/deploy/create_benchmark_configmap.sh" "${CONTEXT}"
kubectl_ctx "${CONTEXT}" apply -k "${REPO_ROOT}/manifests/common"

if [[ "${EXPOSE_NODEPORT:-0}" == "1" ]]; then
  if [[ "${ENV_NAME}" == "kind-cloud" ]]; then
    kubectl_ctx "${CONTEXT}" apply -f "${REPO_ROOT}/manifests/kind/service-nodeport-patch.yaml"
  elif [[ "${ENV_NAME}" == "k3s-edge" ]]; then
    kubectl_ctx "${CONTEXT}" apply -f "${REPO_ROOT}/manifests/k3s/service-nodeport-patch.yaml"
  fi
fi

kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" rollout status deployment/coredns-vnf --timeout=180s
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" rollout status deployment/dns-benchmark-runner --timeout=180s
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" wait --for=condition=Ready pod/dns-test-client --timeout=180s

kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" get pods -o wide
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" get svc
