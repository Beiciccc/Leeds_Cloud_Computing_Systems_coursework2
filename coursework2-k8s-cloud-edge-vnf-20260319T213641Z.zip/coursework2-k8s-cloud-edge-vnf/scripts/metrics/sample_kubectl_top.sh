#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl

CONTEXT="${1:-}"
DURATION_SECONDS="${2:-}"
OUTPUT_FILE="${3:-}"

if [[ -z "${CONTEXT}" || -z "${DURATION_SECONDS}" || -z "${OUTPUT_FILE}" ]]; then
  echo "Usage: $0 <kube-context> <duration-seconds> <output-file>" >&2
  exit 1
fi

ensure_dir "$(dirname "${OUTPUT_FILE}")"
printf 'timestamp_utc,pod,cpu_raw,memory_raw\n' > "${OUTPUT_FILE}"

end_epoch=$(( $(date +%s) + DURATION_SECONDS ))
while (( $(date +%s) <= end_epoch )); do
  timestamp="$(timestamp_utc)"
  top_output="$(kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" top pod -l "${VNF_APP_LABEL}" --no-headers 2>/dev/null || true)"
  if [[ -z "${top_output}" ]]; then
    printf '%s,%s,%s,%s\n' "${timestamp}" "NO_DATA" "NA" "NA" >> "${OUTPUT_FILE}"
  else
    while read -r pod cpu memory; do
      [[ -z "${pod}" ]] && continue
      printf '%s,%s,%s,%s\n' "${timestamp}" "${pod}" "${cpu}" "${memory}" >> "${OUTPUT_FILE}"
    done <<< "${top_output}"
  fi
  sleep "${METRICS_INTERVAL_SECONDS}"
done

