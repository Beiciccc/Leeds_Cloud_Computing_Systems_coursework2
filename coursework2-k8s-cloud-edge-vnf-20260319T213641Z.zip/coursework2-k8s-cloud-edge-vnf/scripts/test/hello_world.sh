#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl

TARGET="${1:-}"
if [[ -z "${TARGET}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context>" >&2
  exit 1
fi

CONTEXT="$(resolve_context "${TARGET}")"
ENV_NAME="$(resolve_environment_name "${TARGET}")"
OUTPUT_DIR="${RESULTS_DIR}/raw/${ENV_NAME}/validation"
SERVER="coredns-vnf.telecom-dns.svc.cluster.local"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"

ensure_dir "${OUTPUT_DIR}"

kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" wait --for=condition=Ready pod/dns-test-client --timeout=180s

declare -A EXPECTED
EXPECTED["ue1.telecom.local"]="10.10.0.11"
EXPECTED["upf.telecom.local"]="10.10.0.12"
EXPECTED["amf.telecom.local"]="10.10.0.13"
EXPECTED["edge-cache.telecom.local"]="10.10.0.14"

LOG_FILE="${OUTPUT_DIR}/hello_world_${TIMESTAMP}.txt"
: > "${LOG_FILE}"

for host in "${!EXPECTED[@]}"; do
  echo "===== ${host} =====" >> "${LOG_FILE}"
  output="$(kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" exec pod/dns-test-client -- nslookup "${host}" "${SERVER}")"
  printf '%s\n\n' "${output}" >> "${LOG_FILE}"
  if [[ "${output}" != *"${EXPECTED[${host}]}"* ]]; then
    echo "Validation failed for ${host}; expected ${EXPECTED[${host}]}" >&2
    exit 1
  fi
done

kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" get pods -o wide > "${OUTPUT_DIR}/pod_state_${TIMESTAMP}.txt"
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" get svc > "${OUTPUT_DIR}/service_state_${TIMESTAMP}.txt"

echo "Hello-world validation completed successfully. Output: ${LOG_FILE}"

