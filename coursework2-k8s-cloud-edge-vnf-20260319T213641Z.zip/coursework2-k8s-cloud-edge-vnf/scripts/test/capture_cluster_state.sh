#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl

TARGET="${1:-}"
if [[ -z "${TARGET}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context>" >&2
  exit 1
fi

CONTEXT="$(resolve_context "${TARGET}")"
ENV_NAME="$(resolve_environment_name "${TARGET}")"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_DIR="${RESULTS_DIR}/raw/${ENV_NAME}/environment/${STAMP}"

ensure_dir "${OUTPUT_DIR}"

kubectl_ctx "${CONTEXT}" cluster-info > "${OUTPUT_DIR}/cluster-info.txt"
kubectl_ctx "${CONTEXT}" get nodes -o wide > "${OUTPUT_DIR}/nodes.txt"
kubectl_ctx "${CONTEXT}" get pods -A -o wide > "${OUTPUT_DIR}/pods-all-namespaces.txt"
kubectl_ctx "${CONTEXT}" get svc -A > "${OUTPUT_DIR}/services-all-namespaces.txt"
kubectl_ctx "${CONTEXT}" -n "${NAMESPACE}" get all > "${OUTPUT_DIR}/telecom-dns-resources.txt"

echo "Saved cluster state snapshot to ${OUTPUT_DIR}"

