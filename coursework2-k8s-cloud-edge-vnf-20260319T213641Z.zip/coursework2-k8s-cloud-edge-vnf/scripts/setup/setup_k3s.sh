#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd curl
require_cmd kubectl

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "K3s setup is intended for Ubuntu 22.04 or another Linux VM." >&2
  exit 1
fi

sudo mkdir -p /etc/rancher/k3s
sudo cp "${REPO_ROOT}/manifests/k3s/k3s-config.yaml" /etc/rancher/k3s/config.yaml

if ! systemctl is-active --quiet k3s; then
  echo "Installing K3s"
  curl -sfL https://get.k3s.io | INSTALL_K3S_EXEC="server --config /etc/rancher/k3s/config.yaml" sh -
else
  echo "K3s is already installed; ensuring it uses the coursework config."
  sudo systemctl restart k3s
fi

mkdir -p "${HOME}/.kube"
sudo cp /etc/rancher/k3s/k3s.yaml "${HOME}/.kube/config-k3s-comp5123m"
sudo chown "$(id -u):$(id -g)" "${HOME}/.kube/config-k3s-comp5123m"

kubectl --kubeconfig "${HOME}/.kube/config-k3s-comp5123m" config rename-context default "${K3S_CONTEXT}" >/dev/null 2>&1 || true

if [[ -f "${HOME}/.kube/config" ]]; then
  merged_config="$(mktemp)"
  KUBECONFIG="${HOME}/.kube/config:${HOME}/.kube/config-k3s-comp5123m" kubectl config view --flatten > "${merged_config}"
  mv "${merged_config}" "${HOME}/.kube/config"
else
  cp "${HOME}/.kube/config-k3s-comp5123m" "${HOME}/.kube/config"
fi

"${REPO_ROOT}/scripts/setup/install_metrics_server.sh" "${K3S_CONTEXT}" || true

kubectl_ctx "${K3S_CONTEXT}" cluster-info
kubectl_ctx "${K3S_CONTEXT}" get nodes -o wide

