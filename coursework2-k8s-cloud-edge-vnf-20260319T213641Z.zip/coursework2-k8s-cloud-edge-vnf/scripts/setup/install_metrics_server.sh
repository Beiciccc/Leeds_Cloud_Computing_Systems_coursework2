#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl

CONTEXT="$(resolve_context "${1:-}")"
if [[ -z "${CONTEXT}" ]]; then
  echo "Usage: $0 <kind|k3s|kube-context>" >&2
  exit 1
fi

METRICS_SERVER_URL="${METRICS_SERVER_URL:-https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml}"

if ! kubectl_ctx "${CONTEXT}" get ns kube-system >/dev/null 2>&1; then
  echo "Context ${CONTEXT} is not reachable." >&2
  exit 1
fi

if ! kubectl_ctx "${CONTEXT}" -n kube-system get deployment metrics-server >/dev/null 2>&1; then
  echo "Applying metrics-server to ${CONTEXT}"
  kubectl_ctx "${CONTEXT}" apply -f "${METRICS_SERVER_URL}"
else
  echo "metrics-server already present in ${CONTEXT}"
fi

current_args="$(kubectl_ctx "${CONTEXT}" -n kube-system get deployment metrics-server -o jsonpath='{.spec.template.spec.containers[0].args}' 2>/dev/null || true)"
if [[ "${current_args}" != *"--kubelet-insecure-tls"* ]]; then
  kubectl_ctx "${CONTEXT}" -n kube-system patch deployment metrics-server --type='json' -p='[
    {"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"},
    {"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-preferred-address-types=InternalIP,Hostname,InternalDNS,ExternalDNS,ExternalIP"}
  ]'
fi

kubectl_ctx "${CONTEXT}" -n kube-system rollout status deployment metrics-server --timeout=180s
kubectl_ctx "${CONTEXT}" top nodes || true

