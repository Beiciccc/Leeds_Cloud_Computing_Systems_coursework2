#!/usr/bin/env bash
set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/common.sh"

require_cmd kubectl
require_cmd docker
require_cmd curl

if ! docker info >/dev/null 2>&1; then
  echo "Docker is installed but the daemon is not reachable." >&2
  exit 1
fi

if ! command -v kind >/dev/null 2>&1; then
  if [[ "$(uname -s)" != "Linux" ]]; then
    echo "Automatic installation is only implemented for Linux. Install kind manually." >&2
    exit 1
  fi
  case "$(uname -m)" in
    x86_64|amd64)
      kind_arch="amd64"
      ;;
    aarch64|arm64)
      kind_arch="arm64"
      ;;
    *)
      echo "Unsupported CPU architecture for automatic kind installation: $(uname -m)" >&2
      exit 1
      ;;
  esac
  echo "kind not found; installing the Linux ${kind_arch} binary to /usr/local/bin/kind"
  tmp_binary="$(mktemp)"
  curl -fsSL -o "${tmp_binary}" "https://kind.sigs.k8s.io/dl/v0.23.0/kind-linux-${kind_arch}"
  chmod +x "${tmp_binary}"
  sudo mv "${tmp_binary}" /usr/local/bin/kind
fi

if kubectl config get-contexts -o name | grep -qx "${KIND_CONTEXT}"; then
  echo "kind context ${KIND_CONTEXT} already exists; skipping cluster creation."
else
  kind create cluster --config "${REPO_ROOT}/manifests/kind/cluster-config.yaml"
fi

"${REPO_ROOT}/scripts/setup/install_metrics_server.sh" "${KIND_CONTEXT}"

kubectl_ctx "${KIND_CONTEXT}" cluster-info
kubectl_ctx "${KIND_CONTEXT}" get nodes -o wide
