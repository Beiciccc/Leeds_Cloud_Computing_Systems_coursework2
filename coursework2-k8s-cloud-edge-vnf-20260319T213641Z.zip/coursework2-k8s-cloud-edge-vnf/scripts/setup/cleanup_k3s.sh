#!/usr/bin/env bash
set -euo pipefail

if [[ -x /usr/local/bin/k3s-uninstall.sh ]]; then
  sudo /usr/local/bin/k3s-uninstall.sh
else
  echo "K3s uninstall script not found; nothing to do."
fi

