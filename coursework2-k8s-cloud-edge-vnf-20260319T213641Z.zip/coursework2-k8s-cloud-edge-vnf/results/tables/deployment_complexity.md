# Deployment Complexity Comparison

This table summarises the actual setup and deployment observations recorded during execution on the cloud-like and edge-like VMs.

| Criterion | kind cloud-like VM | K3s edge-like VM |
| --- | --- | --- |
| Installation approach | Docker-based local Kubernetes using `kind create cluster` | Lightweight Kubernetes installed with the K3s install script |
| Extra components needed | `metrics-server` usually added explicitly | `metrics-server` often present already, but must be checked |
| Additional platform tuning | Docker daemon must be running; metrics-server patch may be needed | kubeconfig copy and permission handling may be needed |
| Deployment of CoreDNS VNF | Same manifests as K3s | Same manifests as kind |
| Hello-world validation path | Same `nslookup` client logic | Same `nslookup` client logic |
| Observed difficulty after execution | Moderate | Moderate |
| Main challenge encountered | The deployment scripts expected the context name `kind-comp5123m-cloud`, but the actual kind context was `kind-cloud`, so the scripts initially failed until the real context name was used explicitly. | The non-root user could not read `/etc/rancher/k3s/k3s.yaml`, so ordinary `kubectl` commands and deployment scripts failed until a user-accessible kubeconfig was prepared. |
| Verified workaround | Use the actual kind context name (`kind-cloud`) when running the deployment, validation and benchmark scripts. | Copy `/etc/rancher/k3s/k3s.yaml` to `~/.kube/config`, change ownership to the user, export `KUBECONFIG`, and then run the same scripts against the K3s cluster while reporting that environment consistently as `k3s-edge`. |
