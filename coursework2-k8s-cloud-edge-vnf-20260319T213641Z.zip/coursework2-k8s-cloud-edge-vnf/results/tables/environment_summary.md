# Environment Summary

This table combines the actual host-side VM configuration with the cluster-side details captured during execution.

| Item | kind cloud-like environment | K3s edge-like environment |
| --- | --- | --- |
| Host VM role | Cloud-like single-node VM | Edge-like single-node VM |
| Host OS | Ubuntu 22.04.5 LTS | Ubuntu 22.04.5 LTS |
| Host architecture | ARM64 / aarch64 | ARM64 / aarch64 |
| Host CPU allocation | 2 vCPU | 2 vCPU |
| Host memory allocation | 4 GB RAM, about 3.8 GiB visible in Ubuntu | 4 GB RAM, about 3.8 GiB visible in Ubuntu |
| Host disk allocation | 20 GB virtual disk, about 19 GiB root filesystem | 20 GB virtual disk, about 19 GiB root filesystem |
| Machine provenance | Cloned from the same base image as the edge VM | Cloned from the same base image as the cloud VM |
| Kubernetes distribution | kind | K3s |
| Kubernetes version observed | v1.35.1 | v1.34.5+k3s1 |
| Node evidence captured | `cloud-control-plane`, which reports Debian GNU/Linux 13 because kind runs Kubernetes nodes as containers on the Ubuntu 22.04.5 ARM64 host VM | `edgevm`, which reports Ubuntu 22.04.5 LTS directly |
| Container runtime observed | `containerd://2.2.1` | `containerd://2.1.5-k3s1` |
| Extra platform tuning | `metrics-server` installed and patched so `kubectl top` worked reliably | `traefik` and `servicelb` disabled; kubeconfig copied for non-root access; `metrics-server` verified |
| Deployed VNF footprint | One CoreDNS replica; requests `25m` CPU and `32Mi` memory, limits `200m` CPU and `128Mi` memory | Same CoreDNS image, manifest, records, and resource limits as kind |
