# Tables

Store final markdown or CSV tables here after processing. Suggested outputs:

- `benchmark_summary.md`
- `deployment_complexity.md`
- `environment_summary.md`

