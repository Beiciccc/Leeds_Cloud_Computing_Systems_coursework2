# Raw Results

This directory stores unmodified outputs captured during execution on the target VMs.

Expected structure:

```text
results/raw/
  kind/
    validation/
    baseline/run01/
    sustained_low/run01/
    sustained_medium/run01/
    sustained_high/run01/
    burst/run01/
  k3s/
    ...
```

Recommended files per run:

- `summary.json`: benchmark summary emitted by `dns_benchmark.py`
- `samples.csv`: per-request latency samples
- `metrics.csv`: `kubectl top` samples during the run
- `command.txt`: exact benchmark command used
- `notes.txt`: runtime observations, failures, or deviations

