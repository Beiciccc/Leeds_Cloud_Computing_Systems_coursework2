# GenAI Troubleshooting Log

## Scope of permitted use

This coursework follows the module's AMBER guidance for GenAI. GenAI was used only in an assistive troubleshooting role to help interpret faults, clarify command and configuration issues, and suggest debugging checks when deployment or monitoring steps were not behaving as expected. GenAI was not used to generate the final solution, fabricate results, replace benchmarking, or determine the final submission claims.

## Disclosure method

The entries below summarise the nature of the troubleshooting query, the debugging direction suggested, the action actually taken, and the verified outcome. They are concise disclosure records rather than verbatim chat transcripts.

## Logged troubleshooting cases

### 1. kind context name mismatch

- **Issue encountered:** The cloud-side deployment and benchmark workflow initially assumed a different kube context name from the one actually created by kind.
- **Observed evidence:** `kubectl config get-contexts` showed `kind-cloud`, while the automated workflow expected `kind-comp5123m-cloud`.
- **Nature of GenAI use:** Guidance was requested on whether the context should be renamed or whether the workflow should be updated to use the actual kind context explicitly.
- **Guidance applied:** Verify the real kube context first and standardise the workflow on the actual context rather than assuming a name.
- **Action and verification:** The available contexts were checked, the deployment and benchmark commands were rerun against `kind-cloud`, and the environment-mapping logic was updated so the results remained consistent.
- **Verified outcome:** The cloud-side deployment, validation, and benchmark steps ran correctly once the actual `kind-cloud` context was used consistently.
- **Lesson learned:** Kubernetes automation should verify the real kube context instead of assuming a hard-coded name.

### 2. K3s kubeconfig permission issue

- **Issue encountered:** The non-root user could not reliably use `kubectl` against the K3s cluster until kubeconfig access was normalised.
- **Observed evidence:** Ordinary user commands did not work cleanly until `/etc/rancher/k3s/k3s.yaml` was copied into the user's kubeconfig path with the correct ownership.
- **Nature of GenAI use:** Guidance was requested on the safest way to make the K3s kubeconfig usable from a normal user account without relying on root for every command.
- **Guidance applied:** Copy the K3s kubeconfig into the user's `.kube` directory, change ownership, and use that file through `KUBECONFIG` or the merged default kubeconfig.
- **Action and verification:** The kubeconfig was copied into `~/.kube/config`, ownership was changed to the normal user, `KUBECONFIG` was exported as needed, and the same deployment and benchmark scripts were rerun.
- **Verified outcome:** The K3s cluster became accessible from the non-root account, and the validation and benchmark workflow completed successfully.
- **Lesson learned:** Lightweight K3s installation is straightforward, but kubeconfig ownership and context handling must be normalised before automation is dependable.

### 3. kind resource-monitoring issue

- **Issue encountered:** The first cloud-side benchmark pass produced valid latency and throughput results, but the kind metrics files contained `NO_DATA`, causing CPU and memory summaries to collapse to zero.
- **Observed evidence:** The original `results/raw/kind-cloud/*/metrics.csv` files contained `NO_DATA`, and the processed resource summary for `kind-cloud` showed zero CPU and memory values.
- **Nature of GenAI use:** Guidance was requested on which part of the monitoring path should be checked first when `kubectl top` was not producing usable resource readings on kind.
- **Guidance applied:** Verify the metrics collection path separately from the benchmark client, confirm that `metrics-server` and `kubectl top` are functioning, and focus on the cloud-side monitoring configuration rather than changing the DNS workload itself.
- **Action and verification:** The cloud-side monitoring setup was checked, the metrics collection path was corrected, and the full kind benchmark suite was rerun so that the resource data was regenerated rather than patched manually.
- **Verified outcome:** The rerun produced valid non-zero CPU and memory results for `kind-cloud`, and the processed tables and figures were regenerated from the corrected raw data.
- **Lesson learned:** Benchmark completion alone is not enough; the monitoring path must be validated early so that resource evidence is trustworthy.

## Final declaration

GenAI was used only to assist troubleshooting in line with the module's AMBER policy. Final implementation, deployment verification, benchmark execution, result checking, and submission decisions remained the student's own responsibility.
