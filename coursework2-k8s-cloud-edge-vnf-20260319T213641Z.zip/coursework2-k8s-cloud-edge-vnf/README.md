# COMP5123M Coursework 2

This repository is a submission-ready project for **Performance Evaluation of Kubernetes for Cloud and Edge Network Functions**. It evaluates a **telecom-relevant DNS VNF** implemented with **CoreDNS** on two matched Kubernetes environments:

- **Cloud-like environment:** `kind`
- **Edge-like environment:** `K3s`

The same VNF manifests, test records, validation steps, benchmark client, and result-processing pipeline are used in both environments. The project is intentionally lightweight so it can run in a lab VM with modest resources while still producing technically credible evidence.

## Why this project design fits the coursework

CoreDNS is a practical telecom-facing VNF because DNS is used for service discovery, local resolution, and control/data-plane support functions in distributed networks. It is also sufficiently lightweight to benchmark fairly on small VMs. This project avoids fabricating numbers: all benchmark and results sections are wired for execution, but any numeric findings must be filled only after the experiments are run on the target VMs.

## Repository structure

```text
coursework2-k8s-cloud-edge-vnf/
  README.md
  REPORT_DRAFT.md
  gradescope_answers/
  manifests/
  scripts/
  results/
  docs/
  references/
  Makefile
```

## Experimental VNF

The deployed VNF is a dedicated CoreDNS instance, separate from the cluster-default DNS. It serves a custom `telecom.local` zone with fixed records:

- `ue1.telecom.local -> 10.10.0.11`
- `upf.telecom.local -> 10.10.0.12`
- `amf.telecom.local -> 10.10.0.13`
- `edge-cache.telecom.local -> 10.10.0.14`

This allows a clean and repeatable hello-world validation path and a stable benchmark target.

## Prerequisites

Use two cloned Ubuntu 22.04.5 LTS VMs with the **same CPU, RAM, and disk allocation** for fairness.

Actual experimental VM configuration used for the results in this repository:

- ARM64 / aarch64
- 2 vCPU
- 4 GB RAM, with about 3.8 GiB visible in Ubuntu
- 20 GB virtual disk, with about 19 GiB in the root filesystem
- outbound Internet access
- `sudo` access

Additional requirements:

- **Cloud VM:** Docker, `kubectl`, `curl`
- **Edge VM:** `kubectl`, `curl`
- **Result-processing machine:** Python 3.10+ and `matplotlib`

Suggested fairness rules:

- Same cloned VM size for kind and K3s
- Same Ubuntu 22.04.5 LTS base image
- No extra workloads running during benchmarks
- Same CoreDNS image, resources, records, and benchmark profiles
- Same repeat count and benchmark durations

## Quick start

### 1. Cloud-like VM with kind

```bash
cd coursework2-k8s-cloud-edge-vnf
./scripts/setup/setup_kind.sh
./scripts/deploy/deploy_vnf.sh kind
./scripts/test/hello_world.sh kind
./scripts/benchmark/run_matrix.sh kind
```

### 2. Edge-like VM with K3s

```bash
cd coursework2-k8s-cloud-edge-vnf
./scripts/setup/setup_k3s.sh
./scripts/deploy/deploy_vnf.sh k3s
./scripts/test/hello_world.sh k3s
./scripts/benchmark/run_matrix.sh k3s
```

### 3. Aggregate results and generate figures

Run this on the machine that holds both `results/raw/kind-cloud/` and `results/raw/k3s-edge/`:

```bash
python3 -m pip install matplotlib
python3 scripts/results/aggregate_results.py --results-root results
python3 scripts/results/generate_figures.py --results-root results
```

### 4. Build a submission archive

```bash
python3 scripts/package/check_answer_lengths.py
./scripts/package/create_submission_archive.sh
```

## Exact setup and deployment steps

### kind

`scripts/setup/setup_kind.sh` performs the following:

1. Verifies `kubectl`, Docker, and `curl`.
2. Installs `kind` on Linux if it is missing.
3. Creates a single-node cluster using `manifests/kind/cluster-config.yaml`.
4. Installs `metrics-server` and patches it for environments where kubelet TLS must be relaxed.
5. Prints `cluster-info` and node details for evidence capture.

### K3s

`scripts/setup/setup_k3s.sh` performs the following:

1. Copies `manifests/k3s/k3s-config.yaml` into `/etc/rancher/k3s/config.yaml`.
2. Installs or restarts K3s using the official install script.
3. Copies kubeconfig to `~/.kube/config-k3s-comp5123m`.
4. Renames the context to `comp5123m-edge` and merges it into `~/.kube/config`.
5. Verifies the cluster and checks for `metrics-server`.

### VNF deployment in both environments

```bash
./scripts/deploy/deploy_vnf.sh kind
./scripts/deploy/deploy_vnf.sh k3s
```

This applies:

- `manifests/common/namespace.yaml`
- `manifests/common/coredns-configmap.yaml`
- `manifests/common/coredns-deployment.yaml`
- `manifests/common/coredns-service.yaml`
- `manifests/common/dns-test-client.yaml`
- `manifests/common/benchmark-runner.yaml`

The benchmark Python script is mounted via a ConfigMap created from `scripts/benchmark/dns_benchmark.py`.

## Hello-world validation path

The required functional validation is already scripted:

```bash
./scripts/test/hello_world.sh kind
./scripts/test/hello_world.sh k3s
```

What it does:

1. Waits for `dns-test-client` to be ready.
2. Runs `nslookup` for each telecom record against the experimental CoreDNS service.
3. Verifies the expected IP address appears in the response.
4. Saves outputs in `results/raw/<environment>/validation/`.

## Benchmark design

Profiles are defined in `scripts/benchmark/experiment_profiles.csv`.

Implemented categories:

1. **Baseline functional latency**
   The client sends single low-rate queries after a short warm-up to estimate baseline latency.
2. **Sustained load**
   Low, medium, and high offered load profiles run for fixed durations with repeated execution.
3. **Burst load**
   A shorter high-concurrency profile checks responsiveness and stability under spikes.

Default scenarios:

| Scenario | QPS | Concurrency | Duration (s) | Repeats |
| --- | ---: | ---: | ---: | ---: |
| baseline | 1 | 1 | 30 | 3 |
| sustained_low | 20 | 2 | 60 | 3 |
| sustained_medium | 100 | 4 | 60 | 3 |
| sustained_high | 200 | 8 | 60 | 3 |
| burst | 400 | 16 | 15 | 3 |

Run all profiles:

```bash
./scripts/benchmark/run_matrix.sh kind
./scripts/benchmark/run_matrix.sh k3s
```

Run a single scenario:

```bash
./scripts/benchmark/run_experiment.sh kind sustained_medium 1
```

## Metrics collection

The project collects the required metrics as follows:

- **Latency:** per-request latency from `dns_benchmark.py`
- **Throughput / achieved query rate:** computed from total requests over elapsed time
- **Success and error rate:** success count, failure count, and percentage
- **CPU and memory usage:** repeated `kubectl top pod` samples during each run

`scripts/metrics/sample_kubectl_top.sh` stores timestamped samples in `metrics.csv` for each run.

## Results pipeline

Raw results are stored under:

```text
results/raw/<environment>/<scenario>/runXX/
```

Then:

```bash
python3 scripts/results/aggregate_results.py --results-root results
python3 scripts/results/generate_figures.py --results-root results
```

Generated outputs:

- `results/processed/benchmark_runs.csv`
- `results/processed/scenario_summary.csv`
- `results/processed/resource_summary.csv`
- `results/figures/latency_comparison.png`
- `results/figures/throughput_comparison.png`
- `results/figures/resource_comparison.png`
- `results/tables/benchmark_summary.md`

## Files for the written submission

- `REPORT_DRAFT.md`: longer academic draft
- `gradescope_answers/`: concise answers aligned to the stated character limits
- `results/tables/environment_summary.md`: concise setup summary of the matched Ubuntu baseline, Kubernetes versions, and observed node details
- `docs/demo_script.md`: longer demo notes
- `gradescope_answers/Q7_demo_video_script.txt`: short 2-minute script
- `GenAI troubleshooting.md`: disclosed log of the actual AI-assisted troubleshooting cases used during setup and benchmarking

## Remaining final-submission steps

The technical work and result generation have now been completed. The remaining manual steps are:

1. Record the 2-minute demo video using `gradescope_answers/Q7_demo_video_script.txt` and `docs/demo_script.md`.
2. Create a fresh submission archive from the latest repository state.
3. Upload the Gradescope answers, the archive or Git link, and the video or video link.

## Notes on academic integrity

This repository is structured to support your own implementation and validation. The benchmark evidence in the report, answers, tables, and figures comes from captured raw outputs and regenerated processed results rather than invented placeholders. `GenAI troubleshooting.md` discloses the actual AI-assisted troubleshooting cases and how the suggestions were applied, in line with the module's AMBER policy.
